<?php
$config['crud_paging'] 			= FALSE;